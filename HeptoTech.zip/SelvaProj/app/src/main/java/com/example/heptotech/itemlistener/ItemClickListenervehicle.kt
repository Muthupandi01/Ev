package com.example.heptotech.itemlistener

interface ItemClickListenervehicle<T> {
    fun onItemSelected(item: T)

}