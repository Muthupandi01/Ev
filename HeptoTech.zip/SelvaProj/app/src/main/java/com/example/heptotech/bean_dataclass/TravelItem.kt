package com.example.heptotech.bean_dataclass

data class TravelItem(
    val date: String,
    val status: String,
    val startLocation: String,
    val endLocation: String
)

