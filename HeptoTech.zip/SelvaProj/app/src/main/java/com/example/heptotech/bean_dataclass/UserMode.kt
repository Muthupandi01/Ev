package com.example.heptotech.bean_dataclass

data class UserMode(
    var isSelected: Boolean = false,

    val imageResId: Int,
    val text: String
)
