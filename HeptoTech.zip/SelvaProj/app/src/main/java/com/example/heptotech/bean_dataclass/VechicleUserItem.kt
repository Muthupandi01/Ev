package com.example.heptotech.bean_dataclass

import android.widget.TextView

data class VechicleUserItem
    (
   val imageResId : Int,
    val text1: String,
    val text2: String,
    var isChecked: Boolean
)

