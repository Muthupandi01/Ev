package com.example.heptotech.bean_dataclass

data class Model(
    val name: String
)