package com.example.heptotech.bean_dataclass

data class Make(
    val imageResId: Int,
    val name: String
)