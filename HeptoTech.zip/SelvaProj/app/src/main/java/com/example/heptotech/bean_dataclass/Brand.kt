package com.example.heptotech.bean_dataclass
data class Brand(
    val imageResId: Int,
    val name: String
)
