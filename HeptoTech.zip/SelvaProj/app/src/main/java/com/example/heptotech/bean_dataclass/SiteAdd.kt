package com.example.heptotech.bean_dataclass

data class SiteAdd(
    val stationname: String,
    val Adderess: String
)
