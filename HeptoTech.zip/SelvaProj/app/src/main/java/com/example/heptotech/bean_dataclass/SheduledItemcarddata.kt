package com.example.heptotech.bean_dataclass

data class SheduledItemcarddata(
    val imgview: Int,
    val stationname: String,
    val date: String,
    val location: String,
//    val editImg: Int,
//    val deleteImg: Int,
    val kwhChild: String,
    val durationChild: String,
    val feeChild: String
)
